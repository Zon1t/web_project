# A파트 테스트 (라운드 1)

1. 이 폴더를 저장소 **밖**에 둔다. 예: `Desktop/WebProject/a-test` (web_project 안에 두면 git에 올라갈 수 있음)
2. 서버를 8081로 실행한다.
3. Git Bash에서
   ```bash
   cd ~/Desktop/WebProject/a-test
   bash round1.sh 2>&1 | tee round1-result.txt
   ```
4. 출력 전체를 Claude에게 붙여 넣는다.
5. SQL Developer에서 `check.sql`을 실행해 결과도 붙여 넣는다. (`:P1` 등은 출력 마지막 줄의 팟 ID)
6. 모든 라운드가 끝나면 `cleanup.sql`로 정리한다.
